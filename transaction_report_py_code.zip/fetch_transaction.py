import logging
import aurora_config
import pymysql

#aurora settings
aurora_host  = "aurora-instance-endpoint"
name = aurora_config.db_username
password = aurora_config.db_password
db_name = aurora_config.db_name

logger = logging.getLogger()
logger.setLevel(logging.INFO)

conn = pymysql.connect(host=aurora_host, user=name, passwd=password, db=db_name, connect_timeout=5)

def handler(event, context):
    """
    This function fetches content from Aurora RDS instance
    """
    clientId = event ["client_id"]
    sql_query = "select * from Transactions where client_id = CAST(clientId AS UNSIGNED)"
    cursor = conn.cursor()
    response = {}
    try:
        cursor.execute(sql_query)
        logger.info("SUCCESS: Connection to Aurora MySQL instance succeeded")
        result = cursor.fetchall()
        print(result)
        response['status']=200
        response['data'] = result
        response['message']="Status OK"
    except:
        logger.info("Connection Failed")
        response['status']=404
        response['data']="-"
        response['message']="Something went wrong..."
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            logger.info("connection is closed")
    
    return response